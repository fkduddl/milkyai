
import 'package:flutter/material.dart';
import 'dart:convert';
import 'dart:math';
import 'package:shared_preferences/shared_preferences.dart';

// 이하 실제 main.dart 내용은 canvas에서 가져온 사용자 코드로 대체됨

// 밀키AI - 로컬 AI 응답 시뮬레이터 (API 없이 사용 가능)

import 'package:flutter/material.dart';
import 'dart:convert';
import 'dart:math';
import 'package:shared_preferences/shared_preferences.dart';

class CharacterInfo {
  final String name;
  final String tone;
  final String personality;
  final Color color;

  CharacterInfo({required this.name, required this.tone, required this.personality, required this.color});
}

class GroupChatScreen extends StatefulWidget {
  final String roomName;
  final List<CharacterInfo> characters;
  final String worldDescription;

  const GroupChatScreen({required this.roomName, required this.characters, required this.worldDescription});

  @override
  _GroupChatScreenState createState() => _GroupChatScreenState();
}

class _GroupChatScreenState extends State<GroupChatScreen> {
  final TextEditingController _controller = TextEditingController();
  List<GroupMessage> messages = [];
  late CharacterInfo selectedSender;
  final String aiCharacter = 'AI 캐릭터';

  @override
  void initState() {
    super.initState();
    selectedSender = widget.characters.first;
    _loadMessages();
  }

  Future<void> _loadMessages() async {
    messages = await GroupChatMemoryManager.loadGroupMessages(widget.roomName);
    setState(() {});
  }

  Future<void> _sendMessage() async {
    final text = _controller.text.trim();
    if (text.isEmpty) return;

    final userMessage = GroupMessage(sender: selectedSender.name, content: text);
    setState(() {
      messages.add(userMessage);
      _controller.clear();
    });
    await GroupChatMemoryManager.saveGroupMessages(widget.roomName, messages);

    // 로컬 응답 생성기 호출
    final reply = _generateLocalReply(text, widget.worldDescription, widget.characters);
    setState(() {
      messages.add(GroupMessage(sender: aiCharacter, content: reply));
    });
    await GroupChatMemoryManager.saveGroupMessages(widget.roomName, messages);
  }

  String _generateLocalReply(String prompt, String world, List<CharacterInfo> characters) {
    final random = Random();
    final sampleReplies = [
      "음... 그런 건 ${characters[random.nextInt(characters.length)].name}한테 물어봐야 하지 않을까?",
      "${selectedSender.name}답게 또 멋진 말을 하네~!",
      "그건 이 세계에서는 절대 있을 수 없는 일이야. ${world}의 법칙에 어긋나니까.",
      "그 말투, 진짜 ${selectedSender.name}이 말하는 것 같네 ㅎㅎ",
      "흠... 아마 ${characters[random.nextInt(characters.length)].name}도 그렇게 생각할걸?",
      "이제 곧 비가 내릴 거야. ${world}에선 항상 그랬으니까."
    ];
    return sampleReplies[random.nextInt(sampleReplies.length)];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('단체 채팅방 - ${widget.roomName}')),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final msg = messages[index];
                final isUser = msg.sender == selectedSender.name;
                final character = widget.characters.firstWhere(
                  (c) => c.name == msg.sender,
                  orElse: () => CharacterInfo(name: msg.sender, tone: '', personality: '', color: Colors.grey[300]!),
                );
                return Align(
                  alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: character.color,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(msg.sender, style: TextStyle(fontSize: 12, color: Colors.grey[700])),
                        SizedBox(height: 4),
                        Text(msg.content),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          Divider(height: 1),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                DropdownButton<CharacterInfo>(
                  value: selectedSender,
                  items: widget.characters
                      .map((c) => DropdownMenuItem(value: c, child: Text(c.name)))
                      .toList(),
                  onChanged: (val) => setState(() => selectedSender = val ?? widget.characters.first),
                ),
                SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      hintText: '메시지를 입력하세요...',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send, color: Colors.pink),
                  onPressed: _sendMessage,
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}

class GroupMessage {
  final String sender;
  final String content;

  GroupMessage({required this.sender, required this.content});

  Map<String, String> toJson() => {
    'sender': sender,
    'content': content,
  };

  static GroupMessage fromJson(Map<String, dynamic> json) => GroupMessage(
    sender: json['sender'],
    content: json['content'],
  );
}

class GroupChatMemoryManager {
  static Future<void> saveGroupMessages(String roomName, List<GroupMessage> messages) async {
    final prefs = await SharedPreferences.getInstance();
    final encoded = messages.map((m) => m.toJson()).toList();
    prefs.setString('groupchat_$roomName', jsonEncode(encoded));
  }

  static Future<List<GroupMessage>> loadGroupMessages(String roomName) async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString('groupchat_$roomName');
    if (data == null) return [];
    final decoded = jsonDecode(data) as List;
    return decoded.map((e) => GroupMessage.fromJson(e)).toList();
  }
}
